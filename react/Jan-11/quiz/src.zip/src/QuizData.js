export const QuizData = [
    {
        id: 0,
        question: `What is the capital of Nigeria?`,
        options: [`New Delhi`, `Abuja`, `Owerri`, `Enugu`],
        answer: `Abuja`
    },
    {
        id: 0,
        question: `What is the capital of India?`,
        options: [`New Delhi`, `Abuja`, `Mumbai`, `Aba`],
        answer: `New Delhi`
    },
    {
        id: 0,
        question: `What is the capital of Australia?`,
        options: [`Melbourne`, `Akokwa`, `Owerri`, `Sydney`],
        answer: `Sydney`
    },
    {
        id: 0,
        question: `What is the capital of Turkey?`,
        options: [`Rijadh`, `Ankara`, `Istanbul`, `Abakaliki`],
        answer: `Ankara`
    },
    {
        id: 0,
        question: `What is the capital of Syria?`,
        options: [`Syria`, `Damascus`, `Anambra`, `Enugu`],
        answer: `Damascus`
    },
]